[//]: # (tags: , ; , ; )
# Subdirectory Test

Just a test to see if my current function will add all files in a subdirectory to the notes[] array.

Yes, it does. yay!
